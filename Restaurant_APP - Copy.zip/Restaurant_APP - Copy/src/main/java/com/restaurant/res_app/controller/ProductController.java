package com.restaurant.res_app.controller;


import java.util.HashMap;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.restaurant.res_app.model.Customer;
import com.restaurant.res_app.model.Product;
import com.restaurant.res_app.repository.ProductRepository;

import exception.ResourceNotFoundException;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v1")
public class ProductController {
	
	@Autowired
	private ProductRepository productRepository;

	@GetMapping("/products")
	public List<Product> getAllcustomers() {
		return productRepository.findAll();
	}

	@GetMapping("/products/{id}")
	public ResponseEntity<Product> getcustomerById(@PathVariable(value = "id") Long id) 
			throws ResourceNotFoundException 
	{
		Product customer = productRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("product not found for this id :: " + id));
		return ResponseEntity.ok().body(customer);
	}
	
	
	@RequestMapping(value = "/products",
    method = RequestMethod.POST,
    produces = MediaType.APPLICATION_JSON_VALUE)
	public Product createcustomer(@RequestBody Product customer) {
		return productRepository.save(customer);
	}
	
	
	@RequestMapping(value = "/products/{id}",
    method = RequestMethod.PUT,
    produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Product> updateproduct(@PathVariable(value = "id") Long customerId,
			@RequestBody Product productDetails) throws ResourceNotFoundException {
		Product product = productRepository.findById(customerId)
				.orElseThrow(() -> new ResourceNotFoundException("customer not found for this id :: " + customerId));

		product.setProductname(productDetails.getProductname());
		product.setDescription(productDetails.getDescription());
		product.setProductprice(productDetails.getProductprice());
		product.setProductcategory(productDetails.getProductcategory());
		product.setImagename(productDetails.getImagename());

		
		//// ADD ALL set and get
		final Product updatedproduct = productRepository.save(product);
		return ResponseEntity.ok(updatedproduct);
	}
	
	@RequestMapping(value = "/products/{id}",
			method = RequestMethod.DELETE,
		    produces = MediaType.APPLICATION_JSON_VALUE)
	public Map<String, Boolean> deletecustomer(@PathVariable(value = "id") Long customer_id)
			throws ResourceNotFoundException {
		Product customer = productRepository.findById(customer_id)
				.orElseThrow(() -> new ResourceNotFoundException("customer not found for this id :: " + customer_id));

		productRepository.delete(customer);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}

}
