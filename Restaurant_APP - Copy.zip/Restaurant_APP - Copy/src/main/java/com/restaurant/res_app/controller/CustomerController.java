package com.restaurant.res_app.controller;
import java.util.HashMap;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.restaurant.res_app.model.Customer;
import com.restaurant.res_app.model.Status;
import com.restaurant.res_app.repository.CustomerRepository;

import exception.ResourceNotFoundException;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v1")
public class CustomerController {
	@Autowired
	private CustomerRepository customerRepository;

	@GetMapping("/customers")
	public List<Customer> getAllcustomers() {
		return customerRepository.findAll();
	}

	@GetMapping("/customers/{id}")
	public ResponseEntity<Customer> getcustomerById(@PathVariable(value = "id") Long id) 
			throws ResourceNotFoundException 
	{
		Customer customer = customerRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("customer not found for this id :: " + id));
		return ResponseEntity.ok().body(customer);
	}
	
	@RequestMapping(value = "/customers",
    method = RequestMethod.POST,
    produces = MediaType.APPLICATION_JSON_VALUE)
	public Customer createcustomer(@RequestBody Customer customer) {
		return customerRepository.save(customer);
	}
	
	@RequestMapping(value = "/customers/login",
			method = RequestMethod.POST,
		    produces = MediaType.APPLICATION_JSON_VALUE)
	public Customer logincustomer(@RequestBody Customer customer) {
				List<Customer> users = customerRepository.findAll();
		        for (Customer other : users) {
		        	System.out.println(customer.getUsername());
		        	System.out.println(other.getUsername() +  " : " + other.getPassword());
		            if (other.getUsername().equals(customer.getUsername()) && other.getPassword().equals(customer.getPassword())) {
		                System.out.println("Got");
		            	return other;
		            }
		        }
		        return null;
	}
	
	@RequestMapping(value = "/customers/{id}",
    method = RequestMethod.PUT,
    produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Customer> updatecustomer(@PathVariable(value = "id") Long customerId,
			@RequestBody Customer customerDetails) throws ResourceNotFoundException {
		Customer customer = customerRepository.findById(customerId)
				.orElseThrow(() -> new ResourceNotFoundException("customer not found for this id :: " + customerId));

		customer.setName(customerDetails.getName());
		customer.setEmail(customerDetails.getEmail());
		customer.setUsername(customerDetails.getUsername());
		customer.setPassword(customerDetails.getPassword());
		customer.setAddress(customerDetails.getAddress());
		customer.setContact(customerDetails.getContact());
		
		//// ADD ALL set and get
		final Customer updatedcustomer = customerRepository.save(customer);
		return ResponseEntity.ok(updatedcustomer);
	}
	
	@RequestMapping(value = "/customers/{id}",
			method = RequestMethod.DELETE,
		    produces = MediaType.APPLICATION_JSON_VALUE)
	public Map<String, Boolean> deletecustomer(@PathVariable(value = "id") Long customer_id)
			throws ResourceNotFoundException {
		Customer customer = customerRepository.findById(customer_id)
				.orElseThrow(() -> new ResourceNotFoundException("customer not found for this id :: " + customer_id));

		customerRepository.delete(customer);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}
}
