package com.restaurant.res_app.model;

public enum Status {
	CUSTOMER,
	BILLS,
	ORDERS,
	PRODUCTS,
	ID,
    SUCCESS,
    USER_ALREADY_EXISTS,
    FAILURE
}