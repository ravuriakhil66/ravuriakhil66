package com.restaurant.res_app.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "admin")
public class Admin {

public Admin(String name, String email, String designation, int contact) {
		super();
		this.name = name;
		this.email = email;
		this.designation = designation;
		this.contact = contact;
		this.username = username;
		this.password = password;
	}

public Admin () {}

private long id;	
private String name;	
private String email;	
private String designation;
private int contact;
private String username;
private String password;

@Id
@GeneratedValue(strategy = GenerationType.AUTO)
public long getId() {
	return id;
}
public void setId(long id) {
	this.id = id;
}

@Column(name = "name", nullable = false)
public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

@Column(name = "email", nullable = false)
public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

@Column(name = "designation", nullable = false)
public String getDesignation() {
	return designation;
}

public void setDesignation(String designation) {
	this.designation = designation;
}

@Column(name = "contact", nullable = false)
public int getContact() {
	return contact;
}

public void setContact(int contact) {
	this.contact = contact;
}

@Column(name = "username", nullable = false)
public String getUsername() {
	return username;
}

public void setUsername(String username) {
	this.username = username;
}

@Column(name = "password", nullable = false)
public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}
}
