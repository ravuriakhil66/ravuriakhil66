package com.restaurant.res_app.controller;

import java.util.HashMap;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.restaurant.res_app.model.Customer;
import com.restaurant.res_app.model.Product;
import com.restaurant.res_app.model.Res_order;
import com.restaurant.res_app.repository.ProductRepository;
import com.restaurant.res_app.repository.Res_orderRepository;

import exception.ResourceNotFoundException;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v1")
public class OrderController {
	
	@Autowired
	private Res_orderRepository res_orderRepository;

	@GetMapping("/res_order")
	public List<Res_order> getAllres_order() {
		return res_orderRepository.findAll();
}
	
	@GetMapping("/res_order/{id}")
	public ResponseEntity<Res_order> getres_orderById(@PathVariable(value = "id") Long id) 
			throws ResourceNotFoundException 
	{
		Res_order res_order = res_orderRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("res_order not found for this id :: " + id));
		return ResponseEntity.ok().body(res_order);
	}
	
	
	@RequestMapping(value = "/res_order",
    method = RequestMethod.POST,
    produces = MediaType.APPLICATION_JSON_VALUE)
	public Res_order createcustomer(@RequestBody Res_order res_order) {
		return res_orderRepository.save(res_order);
	}
	
	
	@RequestMapping(value = "/updateorder",
		    method = RequestMethod.POST,
		    produces = MediaType.APPLICATION_JSON_VALUE)
			public Res_order updateOrder(@RequestBody Res_order res_order) {
				System.out.println(res_order.toString());
				return res_orderRepository.save(res_order);
			}
	
	
	@RequestMapping(value = "/res_order/{id}",
    method = RequestMethod.PUT,
    produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Res_order> updateres_order(@PathVariable(value = "id") Long res_orderId,
			@RequestBody Res_order res_orderDetails) throws ResourceNotFoundException {
		Res_order res_order= res_orderRepository.findById(res_orderId)
				.orElseThrow(() -> new ResourceNotFoundException("res_order not found for this id :: " + res_orderId));

		res_order.setOrderid(res_orderDetails.getOrderid());
		res_order.setCustomerid(res_orderDetails.getCustomerid());
		res_order.setProductid(res_orderDetails.getProductid());
		res_order.setQuantity(res_orderDetails.getQuantity());
		
		
		//// ADD ALL set and get
		final Res_order updatedres_order = res_orderRepository.save(res_order);
		return ResponseEntity.ok(updatedres_order);
	}
	
	@RequestMapping(value = "/res_orders/{id}",
			method = RequestMethod.DELETE,
		    produces = MediaType.APPLICATION_JSON_VALUE)
	public Map<String, Boolean> deletecustomer(@PathVariable(value = "id") Long res_order_id)
			throws ResourceNotFoundException {
		Res_order res_order = res_orderRepository.findById(res_order_id)
				.orElseThrow(() -> new ResourceNotFoundException("res_order not found for this id :: " + res_order_id));

		res_orderRepository.delete(res_order);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}

}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
