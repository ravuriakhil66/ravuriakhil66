package com.restaurant.res_app.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "res_order")
public class Res_order {
	
	public Res_order(String orderid, long customerid, int productid, int quantity, String imagename) {
		super();
		this.orderid = orderid;
		this.customerid = customerid;
		this.productid = productid;
		this.quantity = quantity;
		this.imagename = imagename;
	}

public Res_order () {
	
}

private long id;
private String orderid;
private long customerid;
private int productid;
private int quantity;
private String imagename;

@Id
@GeneratedValue(strategy = GenerationType.AUTO)
public long getId() {
	return id;
}

public void setId(long id) {
	this.id = id;
}

@Column(name = "orderid", nullable = false)
public String getOrderid() {
	return orderid;
}

public void setOrderid(String orderid) {
	this.orderid = orderid;
}

@Column(name = "customerid", nullable = false)
public long getCustomerid() {
	return customerid;
}

public void setCustomerid(long customerid) {
	this.customerid = customerid;
}

@Column(name = "productid", nullable = false)
public int getProductid() {
	return productid;
}

public void setProductid(int productid) {
	this.productid = productid;
}

@Column(name = "quantity", nullable = false)
public int getQuantity() {
	return quantity;
}

public void setQuantity(int quantity) {
	this.quantity = quantity;
}

@Column(name = "imagename", nullable = false)
public String getImagename() {
	return imagename;
}

public void setImagename(String imagename) {
	this.imagename = imagename;
}

}

