package com.restaurant.res_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResApp_Application {

	public static void main(String[] args) {
		SpringApplication.run(ResApp_Application.class, args);
	}

}