package com.restaurant.res_app.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "product")
public class Product {
	
	public Product(String productname, String description, int productprice, String productcategory, String imagename) {
		super();
		this.productname = productname;
		this.description = description;
		this.productprice = productprice;
		this.productcategory = productcategory;
		this.imagename = imagename;
	}
	
	public Product () {
		
	}
	
	private long id;
	private String productname;
	private String description;
	private int productprice;
	private String productcategory;
	private String imagename;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	@Column(name = "productname", nullable = false)
	public String getProductname() {
		return productname;
	}

	public void setProductname(String productname) {
		this.productname = productname;
	}

	@Column(name = "description", nullable = false)
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Column(name = "productprice", nullable = false)
	public int getProductprice() {
		return productprice;
	}

	public void setProductprice(int productprice) {
		this.productprice = productprice;
	}

	@Column(name = "productcategory", nullable = false)
	public String getProductcategory() {
		return productcategory;
	}

	public void setProductcategory(String productcategory) {
		this.productcategory = productcategory;
	}

	@Column(name = "imagename", nullable = false)
	public String getImagename() {
		return imagename;
	}

	public void setImagename(String imagename) {
		this.imagename = imagename;
	}
	
	

}
