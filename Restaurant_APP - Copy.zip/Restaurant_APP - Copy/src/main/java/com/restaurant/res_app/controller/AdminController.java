package com.restaurant.res_app.controller;

import java.util.HashMap;

import java.util.Map;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.restaurant.res_app.model.Admin;
import com.restaurant.res_app.model.Bill;
import com.restaurant.res_app.repository.AdminRepository;

import exception.ResourceNotFoundException;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v1")
public class AdminController {
	@Autowired
	private AdminRepository adminRepository;
	
	
	@GetMapping("/admins")
	public List<Admin> getAlladmins() {
		return adminRepository.findAll();
	}

	@GetMapping("/admins/{id}")
	public ResponseEntity<Admin> getadminById(@PathVariable(value = "id") Long id) 
			throws ResourceNotFoundException 
	{
		Admin admin = adminRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("admin not found for this id :: " + id));
		return ResponseEntity.ok().body(admin);
	}
		
	@RequestMapping(value = "/admins",method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE)
	public Admin createbill(@RequestBody Admin admin) {
			return adminRepository.save(admin);
	}
				
				@RequestMapping(value = "/admins/{id}",
			    method = RequestMethod.PUT,
			    produces = MediaType.APPLICATION_JSON_VALUE)
				public ResponseEntity<Admin> updatebill(@PathVariable(value = "id") Long adminId,
						@RequestBody Admin adminDetails) 
								throws ResourceNotFoundException {
					Admin admin = adminRepository.findById(adminId)
							.orElseThrow(() -> new ResourceNotFoundException("admin not found for this id :: " + adminId));

					admin.setId(adminDetails.getId());					
					admin.setName(adminDetails.getName());
					admin.setEmail(adminDetails.getEmail());
					admin.setEmail(adminDetails.getEmail());
					admin.setDesignation(adminDetails.getDesignation());
					admin.setContact(adminDetails.getContact());
					admin.setUsername(adminDetails.getUsername());
					admin.setPassword(adminDetails.getPassword());
					//// ADD ALL set and get
					final Admin updatedadmin = adminRepository.save(admin);
					return ResponseEntity.ok(updatedadmin);
				}
				
				@RequestMapping(value = "/admins/{id}",
						method = RequestMethod.DELETE,
					    produces = MediaType.APPLICATION_JSON_VALUE)
				public Map<String, Boolean> deleteadmin(@PathVariable(value = "id") Long admin_id)
						throws ResourceNotFoundException {
					Admin admin = adminRepository.findById(admin_id)
							.orElseThrow(() -> new ResourceNotFoundException("admin not found for this id :: " + admin_id));

					adminRepository.delete(admin);
					Map<String, Boolean> response = new HashMap<>();
					response.put("deleted", Boolean.TRUE);
					return response;
				}
			


}


	

