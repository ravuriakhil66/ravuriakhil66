package com.restaurant.res_app.controller;

import java.util.HashMap;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.restaurant.res_app.model.Bill;
import com.restaurant.res_app.model.Bill;
import com.restaurant.res_app.repository.BillRepository;
import com.restaurant.res_app.repository.BillRepository;

import exception.ResourceNotFoundException;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v1")
public class BillController {
	@Autowired
	private BillRepository billRepository;

	@GetMapping("/bills")
	public List<Bill> getAllbills() {
		return billRepository.findAll();
	}

	@GetMapping("/bills/{id}")
	public ResponseEntity<Bill> getbillById(@PathVariable(value = "id") Long id) 
			throws ResourceNotFoundException 
	{
		Bill bill = billRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("bill not found for this id :: " + id));
		return ResponseEntity.ok().body(bill);
	}
		
	@RequestMapping(value = "/bills",method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE)
	public Bill createbill(@RequestBody Bill bill) {
			return billRepository.save(bill);
	}
				
				@RequestMapping(value = "/bills/{id}",
			    method = RequestMethod.PUT,
			    produces = MediaType.APPLICATION_JSON_VALUE)
				public ResponseEntity<Bill> updatebill(@PathVariable(value = "id") Long billId,
						@RequestBody Bill billDetails) 
								throws ResourceNotFoundException {
					Bill bill = billRepository.findById(billId)
							.orElseThrow(() -> new ResourceNotFoundException("bill not found for this id :: " + billId));

					bill.setId(billDetails.getId());
					bill.setOrderid(billDetails.getOrderid());
					bill.setCustomerid(billDetails.getCustomerid());
					bill.setTotalprice(billDetails.getTotalprice());
					bill.setPayment_status(billDetails.getPayment_status());
					bill.setTransaction_no(billDetails.getTransaction_no());
					bill.setDate_time(billDetails.getDate_time());
					//// ADD ALL set and get
					final Bill updatedbill = billRepository.save(bill);
					return ResponseEntity.ok(updatedbill);
				}
				
				@RequestMapping(value = "/bills/{id}",
						method = RequestMethod.DELETE,
					    produces = MediaType.APPLICATION_JSON_VALUE)
				public Map<String, Boolean> deletebill(@PathVariable(value = "id") Long bill_id)
						throws ResourceNotFoundException {
					Bill bill = billRepository.findById(bill_id)
							.orElseThrow(() -> new ResourceNotFoundException("bill not found for this id :: " + bill_id));

					billRepository.delete(bill);
					Map<String, Boolean> response = new HashMap<>();
					response.put("deleted", Boolean.TRUE);
					return response;
				}
			


}
