package com.restaurant.res_app.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "bill")
public class Bill {

	public Bill(String orderid, long customerid, int totalprice, int payment_status, String transaction_no,
			Date date_time) {
		super();
		this.orderid = orderid;
		this.customerid = customerid;
		this.totalprice = totalprice;
		this.payment_status = payment_status;
		this.transaction_no = transaction_no;
		this.date_time = date_time;
	}
	public Bill () {}
	
	private long id;	
	private String orderid;	
	private long customerid;	
	private int totalprice;
	private int payment_status;
	private String transaction_no;	
	private Date date_time;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	
	@Column(name = "orderid", nullable = false)
	public String getOrderid() {
		return orderid;
	}
	public void setOrderid(String orderid) {
		this.orderid = orderid;
	}
	
	@Column(name = "customerid", nullable = false)
	public long getCustomerid() {
		return customerid;
	}
	public void setCustomerid(long customerid) {
		this.customerid = customerid;
	}
	
	@Column(name = "totalprice", nullable = false)
	public int getTotalprice() {
		return totalprice;
	}
	public void setTotalprice(int totalprice) {
		this.totalprice = totalprice;
	}
	
	@Column(name = "payment_status", nullable = false)
	public int getPayment_status() {
		return payment_status;
	}
	public void setPayment_status(int payment_status) {
		this.payment_status = payment_status;
	}
	
	@Column(name = "transaction_no", nullable = false)
	public String getTransaction_no() {
		return transaction_no;
	}
	public void setTransaction_no(String transaction_no) {
		this.transaction_no = transaction_no;
	}
	
	@Column(name = "date_time", nullable = false)
	public Date getDate_time() {
		return date_time;
	}
	public void setDate_time(Date date_time) {
		this.date_time = date_time;
	}
}

