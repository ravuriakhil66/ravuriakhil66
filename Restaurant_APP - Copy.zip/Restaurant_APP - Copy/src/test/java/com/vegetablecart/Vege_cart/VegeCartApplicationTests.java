package com.vegetablecart.Vege_cart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VegeCartApplicationTests {

	@Test
	void contextLoads() {
	}

}
